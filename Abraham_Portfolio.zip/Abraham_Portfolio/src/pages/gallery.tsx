import { useState, useEffect, useCallback } from 'react';
import { Helmet } from '@dr.pogodin/react-helmet';
import { motion, AnimatePresence } from 'motion/react';
import { X, ChevronLeft, ChevronRight } from 'lucide-react';

// ─── All gallery images ───────────────────────────────────────────────────────
const ALL_IMAGES = [
  // Weddings
  { id: 1,  slot: 'gallery/wedding-bride-bouquet',     caption: 'Bride & Bouquet'       },
  { id: 2,  slot: 'gallery/wedding-kiss-tree',         caption: 'First Kiss'            },
  { id: 3,  slot: 'gallery/wedding-groomsmen-porch',   caption: 'The Groomsmen'         },
  { id: 4,  slot: 'gallery/wedding-bride-flowers',     caption: 'Bridal Portrait'       },
  // Portraits
  { id: 5,  slot: 'gallery/portrait-man-bulldog',      caption: 'Man & Bulldog'         },
  { id: 6,  slot: 'gallery/portrait-man-cat-stairs',   caption: 'Dark Stairway'         },
  { id: 7,  slot: 'gallery/portrait-man-bird-night',   caption: 'Night Bird'            },
  { id: 8,  slot: 'gallery/portrait-couple-city',      caption: 'City Overlook'         },
  { id: 9,  slot: 'gallery/portrait-neon-stairs',      caption: 'Neon Blue'             },
  { id: 10, slot: 'gallery/portrait-neon-money',       caption: 'Neon & Cash'           },
  { id: 11, slot: 'gallery/portrait-neon-cash',        caption: 'Stairwell Series I'    },
  { id: 12, slot: 'gallery/portrait-neon-staircase',   caption: 'Stairwell Series II'   },
  // Events
  { id: 13, slot: 'gallery/events-wrestler-flip',      caption: 'The Flip'              },
  // Street / Landscape
  { id: 14, slot: 'gallery/street-demon-statue',       caption: 'Demon at Night'        },
  { id: 15, slot: 'gallery/landscape-winter-river',    caption: 'Winter River'          },
  { id: 16, slot: 'gallery/landscape-moon',            caption: 'Crescent Moon'         },
  { id: 17, slot: 'gallery/events-football-stadium',   caption: 'Game Day'              },
  // Desert portraits
  { id: 18, slot: 'gallery/portrait-desert-smoking',   caption: 'Desert Air'            },
  { id: 19, slot: 'gallery/portrait-desert-chair',     caption: 'Sandia Mountains'      },
];

// ─── Lightbox ─────────────────────────────────────────────────────────────────
function Lightbox({
  images,
  index,
  onClose,
  onPrev,
  onNext,
}: {
  images: typeof ALL_IMAGES;
  index: number;
  onClose: () => void;
  onPrev: () => void;
  onNext: () => void;
}) {
  const img = images[index];

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowLeft') onPrev();
      if (e.key === 'ArrowRight') onNext();
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [onClose, onPrev, onNext]);

  return (
    <motion.div
      className="fixed inset-0 z-50 flex items-center justify-center"
      style={{ background: 'hsl(var(--overlay-dark) / 0.97)' }}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.25 }}
      onClick={onClose}
    >
      {/* Close */}
      <button
        className="absolute top-6 right-6 z-10 p-2 transition-opacity hover:opacity-60"
        style={{ color: 'hsl(var(--foreground))' }}
        onClick={onClose}
        aria-label="Close lightbox"
      >
        <X size={24} />
      </button>

      {/* Prev */}
      <button
        className="absolute left-4 md:left-8 z-10 p-3 transition-opacity hover:opacity-60"
        style={{ color: 'hsl(var(--foreground))' }}
        onClick={e => { e.stopPropagation(); onPrev(); }}
        aria-label="Previous image"
      >
        <ChevronLeft size={32} />
      </button>

      {/* Image */}
      <AnimatePresence mode="wait">
        <motion.div
          key={img.id}
          className="relative flex flex-col items-center px-16 md:px-24"
          initial={{ opacity: 0, scale: 0.97 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.97 }}
          transition={{ duration: 0.3 }}
          onClick={e => e.stopPropagation()}
        >
          <img
            src={`/airo-assets/images/${img.slot}`}
            alt={img.caption}
            className="max-h-[80vh] max-w-full object-contain"
            style={{ boxShadow: '0 0 80px hsl(var(--shadow-dark) / 0.8)' }}
          />
          <div className="mt-5 text-center">
            <p className="text-sm font-light" style={{ color: 'hsl(var(--muted-foreground))' }}>
              {img.caption}
            </p>
            <p className="text-xs mt-2" style={{ color: 'hsl(var(--muted-foreground) / 0.5)' }}>
              {index + 1} / {images.length}
            </p>
          </div>
        </motion.div>
      </AnimatePresence>

      {/* Next */}
      <button
        className="absolute right-4 md:right-8 z-10 p-3 transition-opacity hover:opacity-60"
        style={{ color: 'hsl(var(--foreground))' }}
        onClick={e => { e.stopPropagation(); onNext(); }}
        aria-label="Next image"
      >
        <ChevronRight size={32} />
      </button>
    </motion.div>
  );
}

// ─── Gallery grid item ────────────────────────────────────────────────────────
function GridItem({
  image,
  onClick,
  delay,
}: {
  image: (typeof ALL_IMAGES)[0];
  onClick: () => void;
  delay: number;
}) {
  const [hovered, setHovered] = useState(false);
  return (
    <motion.div
      className="relative overflow-hidden cursor-pointer"
      style={{ aspectRatio: '3/4' }}
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-40px' }}
      transition={{ duration: 0.7, delay, ease: 'easeOut' as const }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      onClick={onClick}
    >
      <img
        src={`/airo-assets/images/${image.slot}`}
        alt={image.caption}
        loading="lazy"
        className="w-full h-full object-cover transition-transform duration-700"
        style={{ transform: hovered ? 'scale(1.05)' : 'scale(1)' }}
      />
      {/* Overlay */}
      <div
        className="absolute inset-0 pointer-events-none transition-opacity duration-500"
        style={{ background: 'hsl(var(--overlay-dark) / 0.5)', opacity: hovered ? 1 : 0 }}
      />
      {/* Caption */}
      <div
        className="absolute bottom-0 left-0 right-0 p-5 pointer-events-none transition-all duration-500"
        style={{ opacity: hovered ? 1 : 0, transform: hovered ? 'translateY(0)' : 'translateY(8px)' }}
      >
        <p className="text-sm font-light mt-0.5" style={{ color: 'hsl(var(--foreground))' }}>
          {image.caption}
        </p>
      </div>
    </motion.div>
  );
}

// ─── Page ─────────────────────────────────────────────────────────────────────
export default function GalleryPage() {
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  const openLightbox = useCallback((index: number) => setLightboxIndex(index), []);
  const closeLightbox = useCallback(() => setLightboxIndex(null), []);
  const prevImage = useCallback(() =>
    setLightboxIndex(i => (i === null ? null : (i - 1 + ALL_IMAGES.length) % ALL_IMAGES.length)), []);
  const nextImage = useCallback(() =>
    setLightboxIndex(i => (i === null ? null : (i + 1) % ALL_IMAGES.length)), []);

  // Lock body scroll when lightbox open
  useEffect(() => {
    document.body.style.overflow = lightboxIndex !== null ? 'hidden' : '';
    return () => { document.body.style.overflow = ''; };
  }, [lightboxIndex]);

  return (
    <>
      <Helmet>
        <title>Photography — Abraham Lopez</title>
        <meta name="description" content="Photography portfolio of Abraham Lopez — portraits, weddings, events, street, and landscape." />
        <link rel="canonical" href="https://abraham.photo/gallery" />
        <meta property="og:title" content="Photography — Abraham Lopez" />
        <meta property="og:description" content="Photography portfolio of Abraham Lopez — portraits, weddings, events, street, and landscape." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://abraham.photo/gallery" />
        <meta name="twitter:card" content="summary_large_image" />
      </Helmet>

      <main className="min-h-screen" style={{ background: 'hsl(var(--background))' }}>
        {/* Page header */}
        <div className="pt-32 pb-16 px-6 md:px-14 max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: 'easeOut' as const }}
          >
            <p className="text-xs tracking-[0.35em] uppercase mb-4" style={{ color: 'hsl(var(--primary))' }}>
              Photography
            </p>
            <h1
              className="text-5xl md:text-7xl font-bold"
              style={{ fontFamily: 'var(--font-heading)', color: 'hsl(var(--foreground))', letterSpacing: '-0.02em' }}
            >
              Gallery
            </h1>
          </motion.div>
        </div>

        {/* Grid */}
        <div className="px-6 md:px-14 pb-32 max-w-7xl mx-auto">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4">
            {ALL_IMAGES.map((img, i) => (
              <GridItem
                key={img.id}
                image={img}
                onClick={() => openLightbox(i)}
                delay={(i % 6) * 0.07}
              />
            ))}
          </div>
        </div>
      </main>

      {/* Lightbox */}
      <AnimatePresence>
        {lightboxIndex !== null && (
          <Lightbox
            images={ALL_IMAGES}
            index={lightboxIndex}
            onClose={closeLightbox}
            onPrev={prevImage}
            onNext={nextImage}
          />
        )}
      </AnimatePresence>
    </>
  );
}
