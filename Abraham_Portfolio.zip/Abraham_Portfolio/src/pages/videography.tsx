import { useState } from 'react';
import { Helmet } from '@dr.pogodin/react-helmet';
import { motion } from 'motion/react';
import { home } from 'virtual:content';

function FadeIn({ children, delay = 0, className = '' }: { children: React.ReactNode; delay?: number; className?: string }) {
  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, y: 28 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-60px' }}
      transition={{ duration: 0.8, delay, ease: 'easeOut' as const }}>
      {children}
    </motion.div>
  );
}

// Map YouTube IDs to uploaded thumbnail slot URLs
const THUMB_MAP: Record<string, string> = {
  cPsbPWNGjGA: '/airo-assets/images/videography/documentary-thumb',
  uHTn6JahKm8: '/airo-assets/images/videography/narrative-1-thumb',
  ZnakxGeq5RU: '/airo-assets/images/videography/narrative-2-thumb',
  ZP1kj9LXJbM: '/airo-assets/images/videography/brand-promo-1-thumb',
  fAa2tkEztzo: '/airo-assets/images/videography/brand-promo-2-thumb',
  '6vP5K_6urzs': '/airo-assets/images/videography/barber-promo-thumb',
};

function VideoThumb({ youtubeId, title }: { youtubeId: string; title: string }) {
  const [hovered, setHovered] = useState(false);
  const thumb = THUMB_MAP[youtubeId];
  const url = `https://www.youtube.com/watch?v=${youtubeId}`;

  return (
    <a
      href={url}
      target="_blank"
      rel="noopener noreferrer"
      className="block group"
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <div className="relative w-full aspect-video overflow-hidden" style={{ background: 'hsl(var(--muted))' }}>
        <img
          src={thumb}
          alt={title}
          loading="lazy"
          className="w-full h-full object-cover transition-transform duration-700"
          style={{ transform: hovered ? 'scale(1.04)' : 'scale(1)' }}
        />
        {/* Dark overlay on hover */}
        <div
          className="absolute inset-0 pointer-events-none transition-opacity duration-300"
          style={{ background: 'hsl(var(--background) / 0.5)', opacity: hovered ? 1 : 0 }}
        />
        {/* Play button */}
        <div
          className="absolute inset-0 flex items-center justify-center pointer-events-none transition-opacity duration-300"
          style={{ opacity: hovered ? 1 : 0.7 }}
        >
          <div
            className="w-14 h-14 rounded-full flex items-center justify-center transition-transform duration-300"
            style={{
              background: 'hsl(var(--primary) / 0.9)',
              transform: hovered ? 'scale(1.1)' : 'scale(1)',
            }}
          >
            {/* Triangle play icon */}
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
              <path d="M6 4l12 6-12 6V4z" fill="hsl(var(--background))" />
            </svg>
          </div>
        </div>
      </div>
      <p className="mt-3 text-sm tracking-[0.15em] uppercase font-light transition-colors duration-300"
        style={{ color: hovered ? 'hsl(var(--primary))' : 'hsl(var(--muted-foreground))' }}>
        {title}
      </p>
    </a>
  );
}

export default function VideographyPage() {
  const featured = home.videography.featured;

  return (
    <>
      <Helmet>
        <title>Videography — Abraham Lopez</title>
        <meta
          name="description"
          content="Cinematic films, narrative shorts, and brand videos by Abraham Lopez — video creative based in Albuquerque, NM."
        />
        <link rel="canonical" href="https://abraham.photo/videography" />
        <meta property="og:title" content="Videography — Abraham Lopez" />
        <meta property="og:description" content="Cinematic films, narrative shorts, and brand videos by Abraham Lopez." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://abraham.photo/videography" />
        <meta name="twitter:card" content="summary_large_image" />
      </Helmet>

      <main className="py-24 md:py-36 px-6 md:px-14" style={{ background: 'hsl(var(--background))' }}>
        <div className="max-w-7xl mx-auto">

          {/* Page heading */}
          <FadeIn>
            <div className="flex items-center gap-6 mb-20">
              <h1 className="text-xs tracking-[0.35em] uppercase font-light" style={{ color: 'hsl(var(--primary))' }}>
                Videography
              </h1>
              <span className="flex-1 h-px" style={{ background: 'hsl(var(--border))' }} />
            </div>
          </FadeIn>

          {/* Featured Film */}
          <FadeIn delay={0.1}>
            <div className="mb-24">
              <div className="flex items-center gap-4 mb-6">
                <span className="text-xs tracking-[0.25em] uppercase font-light" style={{ color: 'hsl(var(--primary))' }}>
                  Featured Film
                </span>
                <span className="flex-1 h-px" style={{ background: 'hsl(var(--border))' }} />
              </div>
              <div className="max-w-3xl">
                <VideoThumb youtubeId="cPsbPWNGjGA" title="Documentary" />
                <p className="text-sm font-light mt-3" style={{ color: 'hsl(var(--muted-foreground))' }}>
                  {featured.description}
                </p>
              </div>
            </div>
          </FadeIn>

          {/* Narrative Short Films */}
          <FadeIn delay={0.08}>
            <div className="mb-24">
              <div className="flex items-center gap-4 mb-8">
                <span className="text-xs tracking-[0.25em] uppercase font-light" style={{ color: 'hsl(var(--primary))' }}>
                  Narrative Short Films
                </span>
                <span className="flex-1 h-px" style={{ background: 'hsl(var(--border))' }} />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <VideoThumb youtubeId="uHTn6JahKm8" title="Narrative Film I" />
                <VideoThumb youtubeId="ZnakxGeq5RU" title="Narrative Film II" />
              </div>
            </div>
          </FadeIn>

          {/* Brand & Promotional */}
          <FadeIn delay={0.16}>
            <div>
              <div className="flex items-center gap-4 mb-8">
                <span className="text-xs tracking-[0.25em] uppercase font-light" style={{ color: 'hsl(var(--primary))' }}>
                  Brand &amp; Promotional
                </span>
                <span className="flex-1 h-px" style={{ background: 'hsl(var(--border))' }} />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <VideoThumb youtubeId="ZP1kj9LXJbM" title="Brand Promo I" />
                <VideoThumb youtubeId="fAa2tkEztzo" title="Brand Promo II" />
                <VideoThumb youtubeId="6vP5K_6urzs" title="Barber Promo" />
              </div>
            </div>
          </FadeIn>

        </div>
      </main>
    </>
  );
}
