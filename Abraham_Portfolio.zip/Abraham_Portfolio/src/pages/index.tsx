import { useRef, useState, type FormEvent } from 'react';
import { Link } from 'react-router';
import { Helmet } from '@dr.pogodin/react-helmet';
import { motion, useScroll, useTransform } from 'motion/react';
import { home } from 'virtual:content';

// ─── Fade-in on scroll ───────────────────────────────────────────────────────
function FadeIn({ children, delay = 0, className = '' }: {children: React.ReactNode;delay?: number;className?: string;}) {
  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, y: 28 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-60px' }}
      transition={{ duration: 0.8, delay, ease: 'easeOut' as const }}>
      {children}
    </motion.div>);

}

// ─── Hero ─────────────────────────────────────────────────────────────────────
function Hero() {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start start', 'end start'] });
  const y = useTransform(scrollYProgress, [0, 1], ['0%', '30%']);

  return (
    <section ref={ref} className="relative h-screen overflow-hidden">
      <motion.div className="absolute inset-0 w-full" style={{ y }}>
        <img
          src="/airo-assets/images/pages/home/hero"
          alt="Abraham — Photographer & Videographer"
          fetchPriority="high"
          loading="eager"
          width={1920}
          height={1080}
          className="w-full object-cover"
          style={{ height: '160%', objectPosition: 'center bottom', marginTop: '-30%' }} />
        
      </motion.div>

      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
          'linear-gradient(to top, hsl(var(--background) / 0.85) 0%, hsl(var(--background) / 0.3) 50%, hsl(var(--background) / 0.1) 100%)'
        }} />
      

      <div className="absolute bottom-12 left-8 md:left-14">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.1, delay: 0.3, ease: 'easeOut' as const }}>
          <h1
            className="text-6xl md:text-8xl lg:text-9xl font-bold leading-none tracking-tight mb-3"
            style={{ fontFamily: 'var(--font-heading)', color: 'hsl(var(--foreground))', letterSpacing: '-0.02em' }}>
            {home.hero.name}
          </h1>
          <p
            className="text-xs md:text-sm tracking-[0.35em] uppercase font-light"
            style={{ color: 'hsl(var(--primary))' }}>
            {home.hero.descriptor}
          </p>
        </motion.div>
      </div>

      <motion.div
        className="absolute bottom-10 right-10 flex flex-col items-center gap-2"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1, delay: 1.2 }}>
        <span className="text-xs tracking-[0.25em] uppercase font-light" style={{ color: 'hsl(var(--muted-foreground))' }}>
          Scroll
        </span>
        <motion.div
          className="w-px h-10"
          style={{ background: 'hsl(var(--primary))' }}
          animate={{ scaleY: [0, 1, 0] }}
          transition={{ duration: 1.8, repeat: Infinity, ease: 'easeInOut' as const }} />
        
      </motion.div>
    </section>);

}

// ─── Gallery section ──────────────────────────────────────────────────────────
const GALLERY_PREVIEW = [
{ slot: 'gallery/wedding-bride-bouquet', caption: 'Bride & Bouquet' },
{ slot: 'gallery/wedding-kiss-tree', caption: 'First Kiss' },
{ slot: 'gallery/portrait-neon-stairs', caption: 'Neon Blue' },
{ slot: 'gallery/portrait-man-bulldog', caption: 'Man & Bulldog' },
{ slot: 'gallery/street-demon-statue', caption: 'Demon at Night' },
{ slot: 'gallery/portrait-man-bird-night', caption: 'Night Bird' }];


function GalleryThumb({ slot, caption, delay }: {slot: string;caption: string;delay: number;}) {
  const [hovered, setHovered] = useState(false);
  return (
    <FadeIn delay={delay} className="w-full h-full">
      <div
        className="relative overflow-hidden w-full h-full cursor-pointer"
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => setHovered(false)}>
        <img
          src={`/airo-assets/images/${slot}`}
          alt={caption}
          loading="lazy"
          className="w-full h-full object-cover transition-transform duration-700"
          style={{ transform: hovered ? 'scale(1.05)' : 'scale(1)' }} />
        
        <div
          className="absolute inset-0 pointer-events-none transition-opacity duration-300"
          style={{ background: 'hsl(var(--background) / 0.5)', opacity: hovered ? 1 : 0 }} />
        
        <div
          className="absolute bottom-0 left-0 right-0 p-4 pointer-events-none transition-all duration-300"
          style={{ opacity: hovered ? 1 : 0, transform: hovered ? 'translateY(0)' : 'translateY(6px)' }}>
          <p className="text-xs tracking-[0.2em] uppercase font-light" style={{ color: 'hsl(var(--foreground))' }}>
            {caption}
          </p>
        </div>
      </div>
    </FadeIn>);

}

function GallerySection() {
  return (
    <section id="gallery" className="py-24 md:py-36 px-6 md:px-14">
      <div className="max-w-7xl mx-auto">
        <FadeIn>
          <div className="flex items-center justify-between mb-16">
            <div className="flex items-center gap-6 flex-1">
              <span className="text-xs tracking-[0.35em] uppercase font-light" style={{ color: 'hsl(var(--primary))' }}>
                Photography
              </span>
              <span className="flex-1 h-px" style={{ background: 'hsl(var(--border))' }} />
            </div>
            <Link
              to="/gallery"
              className="ml-8 text-xs tracking-[0.25em] uppercase font-light transition-colors duration-300 pb-0.5 shrink-0"
              style={{ color: 'hsl(var(--primary))', borderBottom: '1px solid hsl(var(--primary) / 0.4)' }}>
              View All →
            </Link>
          </div>
        </FadeIn>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-3 md:gap-4">
          <div className="md:col-span-5" style={{ height: '520px' }}>
            <GalleryThumb slot={GALLERY_PREVIEW[0].slot} caption={GALLERY_PREVIEW[0].caption} delay={0} />
          </div>
          <div className="md:col-span-7 flex flex-col gap-3 md:gap-4">
            <div style={{ height: '252px' }}>
              <GalleryThumb slot={GALLERY_PREVIEW[1].slot} caption={GALLERY_PREVIEW[1].caption} delay={0.1} />
            </div>
            <div style={{ height: '252px' }}>
              <GalleryThumb slot={GALLERY_PREVIEW[2].slot} caption={GALLERY_PREVIEW[2].caption} delay={0.15} />
            </div>
          </div>
          {GALLERY_PREVIEW.slice(3).map((img, i) =>
          <div key={img.slot} className="md:col-span-4" style={{ height: '320px' }}>
              <GalleryThumb slot={img.slot} caption={img.caption} delay={0.1 + i * 0.08} />
            </div>
          )}
        </div>
      </div>
    </section>);

}

// ─── Videography section (homepage preview — 2 videos only) ──────────────────
const VIDEO_THUMBS: Record<string, string> = {
  cPsbPWNGjGA: '/airo-assets/images/videography/documentary-thumb',
  '6vP5K_6urzs': '/airo-assets/images/videography/barber-promo-thumb'
};

function VideoThumb({ youtubeId, title }: {youtubeId: string;title: string;}) {
  const [hovered, setHovered] = useState(false);
  return (
    <a
      href={`https://www.youtube.com/watch?v=${youtubeId}`}
      target="_blank"
      rel="noopener noreferrer"
      className="block"
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}>
      
      <div className="relative w-full aspect-video overflow-hidden" style={{ background: 'hsl(var(--muted))' }}>
        <img
          src={VIDEO_THUMBS[youtubeId]}
          alt={title}
          loading="lazy"
          className="w-full h-full object-cover transition-transform duration-700"
          style={{ transform: hovered ? 'scale(1.04)' : 'scale(1)' }} />
        
        <div
          className="absolute inset-0 pointer-events-none transition-opacity duration-300"
          style={{ background: 'hsl(var(--background) / 0.5)', opacity: hovered ? 1 : 0 }} />
        
        <div
          className="absolute inset-0 flex items-center justify-center pointer-events-none transition-opacity duration-300"
          style={{ opacity: hovered ? 1 : 0.7 }}>
          
          <div
            className="w-14 h-14 rounded-full flex items-center justify-center transition-transform duration-300"
            style={{ background: 'hsl(var(--primary) / 0.9)', transform: hovered ? 'scale(1.1)' : 'scale(1)' }}>
            
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
              <path d="M6 4l12 6-12 6V4z" fill="hsl(var(--background))" />
            </svg>
          </div>
        </div>
      </div>
      <p className="mt-4 text-sm tracking-[0.15em] uppercase font-light transition-colors duration-300"
      style={{ color: hovered ? 'hsl(var(--primary))' : 'hsl(var(--muted-foreground))' }}>
        {title}
      </p>
    </a>);

}

function VideographySection() {
  return (
    <section
      id="videography"
      className="py-24 md:py-36 px-6 md:px-14"
      style={{ background: 'hsl(var(--card))' }}>
      <div className="max-w-7xl mx-auto">
        <FadeIn>
          <div className="flex items-center justify-between mb-16">
            <div className="flex items-center gap-6 flex-1">
              <span className="text-xs tracking-[0.35em] uppercase font-light" style={{ color: 'hsl(var(--primary))' }}>
                {home.videography.label}
              </span>
              <span className="flex-1 h-px" style={{ background: 'hsl(var(--border))' }} />
            </div>
            <Link
              to="/videography"
              className="ml-8 text-xs tracking-[0.25em] uppercase font-light transition-colors duration-300 pb-0.5 shrink-0"
              style={{ color: 'hsl(var(--primary))', borderBottom: '1px solid hsl(var(--primary) / 0.4)' }}>
              View All →
            </Link>
          </div>
        </FadeIn>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <FadeIn delay={0.1}>
            <VideoThumb youtubeId="cPsbPWNGjGA" title="Documentary" />
          </FadeIn>
          <FadeIn delay={0.2}>
            <VideoThumb youtubeId="6vP5K_6urzs" title="Barber Promo" />
          </FadeIn>
        </div>
      </div>
    </section>);

}

// ─── Contact section ──────────────────────────────────────────────────────────
type FormStatus = 'idle' | 'sending' | 'success' | 'error';

function ContactSection() {
  const [status, setStatus] = useState<FormStatus>('idle');
  const [errorMsg, setErrorMsg] = useState('');

  async function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const formData = new FormData(form);

    // Honeypot check — bail silently if a bot filled it
    if (formData.get('_gotcha')) return;

    const name = String(formData.get('name') ?? '').trim();
    const email = String(formData.get('email') ?? '').trim();
    const eventDate = String(formData.get('event-date') ?? '').trim();
    const eventType = String(formData.get('event-type') ?? '').trim();
    const message = String(formData.get('message') ?? '').trim();

    setStatus('sending');
    setErrorMsg('');

    try {
      // Field mapping: only the message textarea goes in messages_attributes[0].body.
      // All other fields (dropdowns, radios, checkboxes) must be added to conversation.data as { "Label": value } pairs.
      const res = await fetch('/api/contact/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          conversation: {
            messages_attributes: [{ body: message || 'New inquiry submitted' }],
            data: {
              __gd_contact_form_title: 'Work Together',
              ...(eventDate && { 'Event Date': eventDate }),
              ...(eventType && { 'Event Type': eventType })
            }
          },
          user: { email, name }
        })
      });

      const json = await res.json();
      if (json.success) {
        setStatus('success');
        form.reset();
      } else {
        throw new Error(json.error || 'Something went wrong.');
      }
    } catch (err) {
      setStatus('error');
      setErrorMsg(err instanceof Error ? err.message : 'Something went wrong. Please try again.');
    }
  }

  return (
    <section
      id="contact"
      className="py-24 md:py-36 px-6 md:px-14"
      style={{ background: 'hsl(var(--background))' }}>
      <div className="max-w-2xl mx-auto">
        <FadeIn>
          <div className="flex items-center gap-6 mb-16">
            <span className="text-xs tracking-[0.35em] uppercase font-light" style={{ color: 'hsl(var(--primary))' }}>
              {home.contact.label}
            </span>
            <span className="flex-1 h-px" style={{ background: 'hsl(var(--border))' }} />
          </div>
        </FadeIn>

        <FadeIn delay={0.1}>
          <p className="text-sm font-light mb-8 tracking-wide" style={{ color: 'hsl(var(--muted-foreground))' }}>
            {home.contact.tagline}
          </p>
          





















          
        </FadeIn>

        <FadeIn delay={0.2}>
          {status === 'success' ?
          <div className="py-16 text-center">
              <p className="text-sm tracking-[0.2em] uppercase font-light mb-3" style={{ color: 'hsl(var(--primary))' }}>
                Inquiry Sent
              </p>
              <p className="text-sm font-light" style={{ color: 'hsl(var(--muted-foreground))' }}>
                Thanks for reaching out — I'll be in touch soon.
              </p>
            </div> :

          <form className="flex flex-col gap-6" onSubmit={handleSubmit}>
              {/* Honeypot — hidden from real users, never sent in POST body */}
              <input
              type="text"
              name="_gotcha"
              tabIndex={-1}
              autoComplete="off"
              style={{ position: 'absolute', left: '-9999px' }}
              aria-hidden="true" />
            

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="flex flex-col gap-2">
                  <label htmlFor="name" className="text-xs tracking-[0.2em] uppercase font-light" style={{ color: 'hsl(var(--muted-foreground))' }}>
                    Name
                  </label>
                  <input
                  id="name"
                  name="name"
                  type="text"
                  required
                  placeholder="Your name"
                  className="bg-transparent border-b py-3 text-sm font-light outline-none transition-colors duration-300 placeholder:text-muted-foreground focus:border-primary"
                  style={{ borderColor: 'hsl(var(--border))', color: 'hsl(var(--foreground))' }} />
                
                </div>
                <div className="flex flex-col gap-2">
                  <label htmlFor="email" className="text-xs tracking-[0.2em] uppercase font-light" style={{ color: 'hsl(var(--muted-foreground))' }}>
                    Email
                  </label>
                  <input
                  id="email"
                  name="email"
                  type="email"
                  required
                  placeholder="your@email.com"
                  className="bg-transparent border-b py-3 text-sm font-light outline-none transition-colors duration-300 placeholder:text-muted-foreground focus:border-primary"
                  style={{ borderColor: 'hsl(var(--border))', color: 'hsl(var(--foreground))' }} />
                
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="flex flex-col gap-2">
                  <label htmlFor="event-date" className="text-xs tracking-[0.2em] uppercase font-light" style={{ color: 'hsl(var(--muted-foreground))' }}>
                    Event Date
                  </label>
                  <input
                  id="event-date"
                  name="event-date"
                  type="date"
                  className="bg-transparent border-b py-3 text-sm font-light outline-none transition-colors duration-300 focus:border-primary"
                  style={{ borderColor: 'hsl(var(--border))', color: 'hsl(var(--foreground))', colorScheme: 'dark' }} />
                
                </div>
                <div className="flex flex-col gap-2">
                  <label htmlFor="event-type" className="text-xs tracking-[0.2em] uppercase font-light" style={{ color: 'hsl(var(--muted-foreground))' }}>
                    Event Type
                  </label>
                  <select
                  id="event-type"
                  name="event-type"
                  className="bg-transparent border-b py-3 text-sm font-light outline-none transition-colors duration-300 focus:border-primary appearance-none cursor-pointer"
                  style={{ borderColor: 'hsl(var(--border))', color: 'hsl(var(--foreground))' }}>
                    <option value="" style={{ background: 'hsl(var(--background))' }}>Select type</option>
                    <option value="Wedding" style={{ background: 'hsl(var(--background))' }}>Wedding</option>
                    <option value="Commercial" style={{ background: 'hsl(var(--background))' }}>Commercial</option>
                    <option value="Portrait" style={{ background: 'hsl(var(--background))' }}>Portrait</option>
                    <option value="Other" style={{ background: 'hsl(var(--background))' }}>Other</option>
                  </select>
                </div>
              </div>

              <div className="flex flex-col gap-2">
                <label htmlFor="message" className="text-xs tracking-[0.2em] uppercase font-light" style={{ color: 'hsl(var(--muted-foreground))' }}>
                  Message
                </label>
                <textarea
                id="message"
                name="message"
                rows={4}
                placeholder="Tell me about your vision..."
                className="bg-transparent border-b py-3 text-sm font-light outline-none transition-colors duration-300 resize-none placeholder:text-muted-foreground focus:border-primary"
                style={{ borderColor: 'hsl(var(--border))', color: 'hsl(var(--foreground))' }} />
              
              </div>

              {status === 'error' &&
            <p role="alert" className="text-xs font-light" style={{ color: 'hsl(var(--destructive))' }}>
                  {errorMsg}
                </p>
            }

              <div className="pt-4">
                <button
                type="submit"
                disabled={status === 'sending'}
                className="px-10 py-4 text-xs tracking-[0.3em] uppercase font-light border transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
                style={{ borderColor: 'hsl(var(--primary))', color: 'hsl(var(--primary))' }}
                onMouseEnter={(e) => {
                  if (status !== 'sending') {
                    e.currentTarget.style.background = 'hsl(var(--primary))';
                    e.currentTarget.style.color = 'hsl(var(--background))';
                  }
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = 'transparent';
                  e.currentTarget.style.color = 'hsl(var(--primary))';
                }}>
                  {status === 'sending' ? 'Sending…' : home.contact.submitLabel}
                </button>
              </div>
            </form>
          }
        </FadeIn>
      </div>
    </section>);

}

// ─── About Me ─────────────────────────────────────────────────────────────────
function AboutSection() {
  return (
    <section
      className="py-24 md:py-32 px-6 md:px-14 max-w-4xl"
      style={{ borderBottom: '1px solid hsl(var(--border))' }}>
      <FadeIn>
        <p className="text-xs tracking-[0.35em] uppercase mb-6" style={{ color: 'hsl(var(--primary))' }}>
          About
        </p>
        <p className="text-base md:text-lg leading-relaxed mb-4" style={{ color: 'hsl(var(--muted-foreground))' }}>
          I'm Abraham Lopez, a video creative based in Albuquerque, New Mexico. My work centers on taking the time to capture genuine, unscripted moments and shape them into something cinematic.
        </p>
        <p className="text-base md:text-lg leading-relaxed" style={{ color: 'hsl(var(--muted-foreground))' }}>
          I believe good storytelling starts with patience: waiting for the real moment instead of manufacturing one. That dedication to craft is what drives everything I create.
        </p>
      </FadeIn>
    </section>);

}

// ─── Page ─────────────────────────────────────────────────────────────────────
export default function HomePage() {
  return (
    <>
      <Helmet>
        <title>Abraham Lopez — Video Creative</title>
        <meta
          name="description"
          content="Abraham Lopez is a video creative based in Albuquerque, NM — cinematic film, documentary, and narrative storytelling." />
        
        <link rel="canonical" href="https://abraham.photo/" />
        <meta property="og:title" content="Abraham Lopez — Video Creative" />
        <meta
          property="og:description"
          content="Abraham Lopez is a video creative based in Albuquerque, NM — cinematic film, documentary, and narrative storytelling." />
        
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://abraham.photo/" />
        <meta name="twitter:card" content="summary_large_image" />
      </Helmet>

      <main>
        <Hero />
        <AboutSection />
        <GallerySection />
        <VideographySection />
        <ContactSection />
      </main>
    </>);

}