import { Helmet } from '@dr.pogodin/react-helmet';
import { motion } from 'motion/react';
import { Link } from 'react-router';
import { about } from 'virtual:content';

const fadeUp = {
  hidden: { opacity: 0, y: 28 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.7, ease: 'easeOut' as const } },
} as const;

const stagger = {
  hidden: {},
  visible: { transition: { staggerChildren: 0.15 } },
} as const;

export default function AboutPage() {
  const siteUrl = 'https://2ddtqrozew.preview.c37.airoapp.ai';
  const url = `${siteUrl}/about`;
  const title = 'About Abraham Lopez — Photographer & Videographer';
  const description =
    'Abraham Lopez is a photographer and videographer based in Albuquerque, NM — specializing in portraits, landscapes, street photography, documentary, and narrative film.';

  return (
    <>
      <Helmet>
        <title>{title}</title>
        <meta name="description" content={description} />
        <link rel="canonical" href={url} />
        <meta property="og:title" content={title} />
        <meta property="og:description" content={description} />
        <meta property="og:url" content={url} />
        <meta property="og:type" content="website" />
        <meta name="twitter:card" content="summary_large_image" />
      </Helmet>

      <main>
        {/* Hero */}
        <section className="relative h-[60vh] min-h-[420px] overflow-hidden flex items-end">
          <img
            src="/airo-assets/images/pages/about/hero"
            alt="Abraham Lopez — behind the camera"
            width={1920}
            height={800}
            fetchPriority="high"
            loading="eager"
            className="absolute inset-0 w-full h-full object-cover"
          />
          <div
            className="absolute inset-0 pointer-events-none"
            style={{
              background:
                'linear-gradient(to top, hsl(var(--background)) 0%, hsl(var(--background) / 0.6) 40%, hsl(var(--background) / 0.1) 100%)',
            }}
          />
          <div className="relative z-10 px-8 md:px-14 pb-14 w-full">
            <motion.p
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-xs tracking-[0.35em] uppercase mb-3"
              style={{ color: 'hsl(var(--primary))' }}
            >
              {about.hero.eyebrow}
            </motion.p>
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.9, delay: 0.35, ease: 'easeOut' as const }}
              className="text-5xl md:text-7xl font-bold leading-none"
              style={{ fontFamily: 'var(--font-heading)', color: 'hsl(var(--foreground))', letterSpacing: '-0.02em' }}
            >
              {about.hero.heading}
            </motion.h1>
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.7, delay: 0.6 }}
              className="mt-3 text-sm md:text-base"
              style={{ color: 'hsl(var(--muted-foreground))' }}
            >
              {about.hero.subheading}
            </motion.p>
          </div>
        </section>

        {/* Story */}
        <section className="py-24 px-8 md:px-14 max-w-3xl">
          <motion.div
            variants={stagger}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
          >
            <motion.h2
              variants={fadeUp}
              className="text-3xl md:text-4xl font-bold mb-10"
              style={{ fontFamily: 'var(--font-heading)', color: 'hsl(var(--foreground))' }}
            >
              {about.story.heading}
            </motion.h2>
            {about.story.paragraphs.map((p) => (
              <motion.p
                key={p.id}
                variants={fadeUp}
                className="text-base md:text-lg leading-relaxed mb-6"
                style={{ color: 'hsl(var(--muted-foreground))' }}
              >
                {p.text}
              </motion.p>
            ))}
          </motion.div>
        </section>

        {/* Approach */}
        <section
          className="py-24 px-8 md:px-14"
          style={{ borderTop: '1px solid hsl(var(--border))' }}
        >
          <motion.div
            variants={stagger}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
          >
            <motion.h2
              variants={fadeUp}
              className="text-3xl md:text-4xl font-bold mb-14"
              style={{ fontFamily: 'var(--font-heading)', color: 'hsl(var(--foreground))' }}
            >
              {about.approach.heading}
            </motion.h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
              {about.approach.items.map((item) => (
                <motion.div key={item.id} variants={fadeUp}>
                  <p
                    className="text-xs tracking-[0.3em] uppercase mb-3"
                    style={{ color: 'hsl(var(--primary))' }}
                  >
                    {item.title}
                  </p>
                  <p
                    className="text-sm md:text-base leading-relaxed"
                    style={{ color: 'hsl(var(--muted-foreground))' }}
                  >
                    {item.description}
                  </p>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </section>

        {/* Credentials */}
        <section
          className="py-24 px-8 md:px-14"
          style={{ borderTop: '1px solid hsl(var(--border))' }}
        >
          <motion.div
            variants={stagger}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
          >
            <motion.h2
              variants={fadeUp}
              className="text-3xl md:text-4xl font-bold mb-14"
              style={{ fontFamily: 'var(--font-heading)', color: 'hsl(var(--foreground))' }}
            >
              {about.credentials.heading}
            </motion.h2>
            <div className="flex flex-col gap-6 max-w-xl">
              {about.credentials.items.map((item) => (
                <motion.div
                  key={item.id}
                  variants={fadeUp}
                  className="flex gap-8 items-baseline"
                  style={{ borderBottom: '1px solid hsl(var(--border))', paddingBottom: '1.25rem' }}
                >
                  <span
                    className="text-xs tracking-[0.25em] uppercase w-28 shrink-0"
                    style={{ color: 'hsl(var(--primary))' }}
                  >
                    {item.label}
                  </span>
                  <span
                    className="text-sm md:text-base"
                    style={{ color: 'hsl(var(--foreground))' }}
                  >
                    {item.value}
                  </span>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </section>

        {/* CTA */}
        <section
          className="py-24 px-8 md:px-14 text-center"
          style={{ borderTop: '1px solid hsl(var(--border))' }}
        >
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, ease: 'easeOut' as const }}
          >
            <h2
              className="text-3xl md:text-5xl font-bold mb-4"
              style={{ fontFamily: 'var(--font-heading)', color: 'hsl(var(--foreground))' }}
            >
              {about.cta.heading}
            </h2>
            <p className="text-sm mb-10" style={{ color: 'hsl(var(--muted-foreground))' }}>
              {about.cta.body}
            </p>
            <Link
              to="/#contact"
              className="inline-block px-10 py-3 text-xs tracking-[0.25em] uppercase transition-colors duration-200"
              style={{
                border: '1px solid hsl(var(--primary))',
                color: 'hsl(var(--primary))',
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLAnchorElement).style.background = 'hsl(var(--primary))';
                (e.currentTarget as HTMLAnchorElement).style.color = 'hsl(var(--background))';
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLAnchorElement).style.background = 'transparent';
                (e.currentTarget as HTMLAnchorElement).style.color = 'hsl(var(--primary))';
              }}
            >
              {about.cta.buttonLabel}
            </Link>
          </motion.div>
        </section>
      </main>
    </>
  );
}
