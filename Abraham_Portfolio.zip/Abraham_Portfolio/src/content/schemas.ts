import { z } from 'zod';
export const schemas = {
  pages: {
    home: z.object({
      "hero": z.object({
        "name": z.string(),
        "descriptor": z.string()
      }),
      "videography": z.object({
        "label": z.string(),
        "featured": z.object({
          "title": z.string(),
          "description": z.string(),
          "youtubeId": z.string()
        }),
        "categories": z.array(z.object({
          "id": z.string(),
          "label": z.string(),
          "videos": z.array(z.object({
            "id": z.string(),
            "title": z.string(),
            "youtubeId": z.string()
          }))
        }))
      }),
      "contact": z.object({
        "label": z.string(),
        "tagline": z.string(),
        "submitLabel": z.string()
      })
    }),
    about: z.object({
      "hero": z.object({
        "eyebrow": z.string(),
        "heading": z.string(),
        "subheading": z.string()
      }),
      "story": z.object({
        "heading": z.string(),
        "paragraphs": z.array(z.object({
          "id": z.string(),
          "text": z.string()
        }))
      }),
      "approach": z.object({
        "heading": z.string(),
        "items": z.array(z.object({
          "id": z.string(),
          "title": z.string(),
          "description": z.string()
        }))
      }),
      "credentials": z.object({
        "heading": z.string(),
        "items": z.array(z.object({
          "id": z.string(),
          "label": z.string(),
          "value": z.string()
        }))
      }),
      "cta": z.object({
        "heading": z.string(),
        "body": z.string(),
        "buttonLabel": z.string()
      })
    }),
    gallery: z.object({
      "CATEGORIES": z.array(z.string())
    })
  }
};
export type Schemas = typeof schemas;