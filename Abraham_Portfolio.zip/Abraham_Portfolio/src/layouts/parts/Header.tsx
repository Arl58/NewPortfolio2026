import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router';

export default function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const handleNavClick = (id: string) => {
    setMenuOpen(false);
    if (location.pathname !== '/') {
      window.location.href = `/#${id}`;
      return;
    }
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <header
      className="fixed top-0 left-0 right-0 z-50 transition-all duration-500"
      style={{
        background: scrolled ? 'hsl(var(--header-bg-solid) / 0.97)' : 'transparent',
        borderBottom: scrolled ? '1px solid hsl(var(--border) / 0.6)' : '1px solid transparent',
        backdropFilter: scrolled ? 'blur(12px)' : 'none',
      }}
    >
      <div className="max-w-7xl mx-auto px-6 md:px-10 h-16 md:h-20 flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="shrink-0 flex items-center">
          <img
            src="/airo-assets/images/logo/horizontal"
            alt="Abraham"
            className="block h-auto max-h-8 md:max-h-10 w-auto max-w-[160px] object-contain self-center"
          />
        </Link>

        {/* Desktop Nav */}
        <nav aria-label="Main navigation" className="hidden md:flex items-center gap-10">
          <Link
            to="/about"
            className="text-xs tracking-[0.2em] uppercase font-light transition-colors duration-300 text-muted-foreground hover:text-primary"
          >
            ABOUT
          </Link>
          <Link
            to="/gallery"
            className="text-xs tracking-[0.2em] uppercase font-light transition-colors duration-300 text-muted-foreground hover:text-primary"
          >
            GALLERY
          </Link>
          <Link
            to="/videography"
            className="text-xs tracking-[0.2em] uppercase font-light transition-colors duration-300 text-muted-foreground hover:text-primary"
          >
            VIDEOGRAPHY
          </Link>
          <button
            onClick={() => handleNavClick('contact')}
            className="text-xs tracking-[0.2em] uppercase font-light transition-colors duration-300 text-muted-foreground hover:text-primary"
          >
            CONTACT
          </button>
        </nav>

        {/* Mobile menu toggle */}
        <button
          className="md:hidden flex flex-col gap-1.5 p-2"
          onClick={() => setMenuOpen(o => !o)}
          aria-label="Toggle menu"
        >
          <span
            className="block w-6 h-px bg-foreground transition-all duration-300"
            style={{ transform: menuOpen ? 'rotate(45deg) translate(3px, 3px)' : 'none' }}
          />
          <span
            className="block w-6 h-px bg-foreground transition-all duration-300"
            style={{ opacity: menuOpen ? 0 : 1 }}
          />
          <span
            className="block w-6 h-px bg-foreground transition-all duration-300"
            style={{ transform: menuOpen ? 'rotate(-45deg) translate(3px, -3px)' : 'none' }}
          />
        </button>
      </div>

      {/* Mobile Nav */}
      {menuOpen && (
        <nav
          aria-label="Mobile navigation"
          className="md:hidden px-6 pb-8 pt-4 flex flex-col gap-6 bg-background"
        >
          <Link
            to="/about"
            className="text-left text-sm tracking-[0.2em] uppercase font-light text-muted-foreground"
            onClick={() => setMenuOpen(false)}
          >
            About
          </Link>
          <Link
            to="/gallery"
            className="text-left text-sm tracking-[0.2em] uppercase font-light text-muted-foreground"
            onClick={() => setMenuOpen(false)}
          >
            Gallery
          </Link>
          <Link
            to="/videography"
            className="text-left text-sm tracking-[0.2em] uppercase font-light text-muted-foreground"
            onClick={() => setMenuOpen(false)}
          >
            Videography
          </Link>
          {[
            { label: 'Contact', id: 'contact' },
          ].map(({ label, id }) => (
            <button
              key={id}
              onClick={() => handleNavClick(id)}
              className="text-left text-sm tracking-[0.2em] uppercase font-light text-muted-foreground"
            >
              {label}
            </button>
          ))}
        </nav>
      )}
    </header>
  );
}
