export default function Footer() {
  return (
    <footer
      className="py-8 px-6 md:px-10"
      style={{
        background: 'hsl(var(--background))',
        borderTop: '1px solid hsl(var(--border))',
      }}
    >
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
        <p
          className="text-xs tracking-widest uppercase font-light"
          style={{ color: 'hsl(var(--muted-foreground))' }}
        >
          © 2026 Abraham
        </p>
        <div className="flex items-center gap-8">
          <a
            href="https://www.instagram.com/ar.l58/"
            target="_blank"
            rel="noopener noreferrer"
            className="text-xs tracking-[0.15em] uppercase font-light transition-colors duration-300"
            style={{ color: 'hsl(var(--muted-foreground))' }}
            onMouseEnter={e => (e.currentTarget.style.color = 'hsl(var(--primary))')}
            onMouseLeave={e => (e.currentTarget.style.color = 'hsl(var(--muted-foreground))')}
          >
            Instagram
          </a>
          <a
            href="mailto:hello@abraham.photo"
            className="text-xs tracking-[0.15em] uppercase font-light transition-colors duration-300"
            style={{ color: 'hsl(var(--muted-foreground))' }}
            onMouseEnter={e => (e.currentTarget.style.color = 'hsl(var(--primary))')}
            onMouseLeave={e => (e.currentTarget.style.color = 'hsl(var(--muted-foreground))')}
          >
            Email
          </a>
        </div>
      </div>
    </footer>
  );
}
